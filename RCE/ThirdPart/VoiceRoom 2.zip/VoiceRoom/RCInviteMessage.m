//
//  RCInviteMessage.m
//  RCE
//
//  Created by 叶孤城 on 2021/4/20.
//

#import "RCInviteMessage.h"

@implementation RCInviteMessage

- (id)initWithInvitationId:(NSString *)invitationId
                senderUser:(NSString *)senderId
                  targetId:(NSString *)targetId
                       cmd:(NSUInteger)cmd
                   content:(NSString *)content {
    if (self = [super init]) {
        self.invitationId = invitationId;
        self.sendUserId = senderId;
        self.targetId = targetId;
        self.cmd = cmd;
        self.content = content;
    }
    return self;
}

- (NSData *)encode {
    NSMutableDictionary *dict = @{@"sendUserId": self.sendUserId,
                                  @"cmd": @(self.cmd),
                                  @"invitationId": self.invitationId}.mutableCopy;
    if (self.targetId != nil) {
        dict[@"targetId"] = self.targetId;
    }
    if (self.content != nil) {
        dict[@"content"] = self.content;
    }
    return [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingFragmentsAllowed error:nil];
}

- (void)decodeWithData:(NSData *)data {
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.invitationId = dict[@"invitationId"];
    self.sendUserId = dict[@"sendUserId"];
    self.cmd = [dict[@"cmd"] unsignedIntValue];
    self.content = dict[@"content"];
    self.targetId = dict[@"targetId"];
}

+ (NSString *)getObjectName {
    return @"RCInviteMessage";
}

- (NSArray<NSString *> *)getSearchableWords {
    return nil;
}

+ (RCMessagePersistent)persistentFlag {
    return MessagePersistent_NONE;
}

@end
