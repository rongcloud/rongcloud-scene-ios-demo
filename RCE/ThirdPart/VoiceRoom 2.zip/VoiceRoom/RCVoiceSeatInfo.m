//
//  RCSeatInfo.m
//  RCVoiceRoomEngine
//
//  Created by zang qilong on 2021/4/14.
//

#import "RCVoiceSeatInfo.h"

@implementation RCVoiceSeatInfo

- (id)copyWithZone:(NSZone *)zone {
    RCVoiceSeatInfo *copy = [[RCVoiceSeatInfo alloc] init];
    copy.status = self.status;
    copy.mute = self.isMuted;
    copy.userId = self.userId;
    copy.extra = self.extra;
    copy.speaking = self.isSpeaking;
    return copy;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"status is %lu, userId is %@, isSpeaking is %d, isMute is %d, islocked %lu",
            (unsigned long)self.status,
            self.userId,
            self.isSpeaking,
            self.isMuted,
            (unsigned long)self.status];
}

@end
