//
//  RCVoiceRoomConfig.m
//  RCVoiceRoomEngine
//
//  Created by zang qilong on 2021/4/14.
//

#import "RCVoiceRoomInfo.h"
#import <YYModel/YYModel.h>

@interface RCVoiceRoomInfo()

@end

@implementation RCVoiceRoomInfo

- (id)copyWithZone:(NSZone *)zone {
    RCVoiceRoomInfo *copy = [[RCVoiceRoomInfo alloc] init];
    copy.audioQuality = self.audioQuality;
    copy.extra = self.extra;
    copy.isFreeEnterSeat = self.isFreeEnterSeat;
    copy.scenario = self.scenario;
    copy.seatCount = self.seatCount;
    copy.roomName = self.roomName;
    return copy;
}

- (NSString *)jsonString {
    return [self yy_modelToJSONString];
}

- (NSDictionary *)createRoomKV {
    return @{@"key": @"RCRoomInfoKey",
             @"value" : [self jsonString]
    };
}

- (BOOL)isEqual:(id)object {
    if (self == object) {
        return YES;
    }
    if (![object isKindOfClass:[RCVoiceRoomInfo class]]) {
        return NO;
    }
    return [self isEqualToRoomInfo:(RCVoiceRoomInfo *)object];
}

- (BOOL)isEqualToRoomInfo:(RCVoiceRoomInfo *)info {
    if(!info) {
        return NO;
    }
    return (self.audioQuality == info.audioQuality)
    && (self.scenario == info.scenario)
    && (self.seatCount == info.seatCount)
    && [self.roomName isEqualToString:info.roomName]
    && [self.extra isEqualToString:info.extra]
    && (self.isFreeEnterSeat == info.isFreeEnterSeat);
}
@end
