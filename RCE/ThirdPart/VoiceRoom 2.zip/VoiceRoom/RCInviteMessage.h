//
//  RCInviteMessage.h
//  RCE
//
//  Created by 叶孤城 on 2021/4/20.
//

#import <RongIMLibCore/RongIMLibCore.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, RCInviteCmdType) {
    RCInviteCmdTypeRequest = 0,
    RCInviteCmdTypeAccept = 1,
    RCInviteCmdTypeReject = 2,
    RCInviteCmdTypeCancel = 3
};

@interface RCInviteMessage : RCMessageContent

@property (nonatomic, copy, nonnull) NSString *invitationId;
@property (nonatomic, copy, nonnull) NSString *sendUserId;
@property (nonatomic, copy, nullable) NSString *targetId;
@property (nonatomic, assign) NSUInteger cmd;
@property (nonatomic, copy, nullable) NSString *content;

- (id)initWithInvitationId:(NSString *)invitationId
                senderUser:(NSString *)senderId
                  targetId:(NSString *)targetId
                       cmd:(NSUInteger)cmd
                   content:(NSString *)content;
@end

NS_ASSUME_NONNULL_END
