//
//  RCVoiceRoomErrorCode.h
//  RCE
//
//  Created by 叶孤城 on 2021/5/26.
//

#ifndef RCVoiceRoomErrorCode_h
#define RCVoiceRoomErrorCode_h
typedef NS_ENUM(NSInteger, RCVoiceRoomErrorCode) {
    RCVoiceRoomSeatIndexOutOfRange = 10001,
    RCVoiceRoomUserAlreadyOnSeat,
    RCVoiceRoomSeatLocked,
    RCVoiceRoomUserPickSelfOnSeat,
    RCVoiceRoomUserKickOutSelfSeat
};

#endif /* RCVoiceRoomErrorCode_h */
