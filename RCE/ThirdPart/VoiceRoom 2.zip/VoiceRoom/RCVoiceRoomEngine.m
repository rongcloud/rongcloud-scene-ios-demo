//
//  RCVoiceRoomEngine.m
//  RCVoiceRoomEngine
//
//  Created by zang qilong on 2021/4/13.
//

#import "RCVoiceRoomEngine.h"
#import <RongIMLibCore/RongIMLibCore.h>
#import <RongChatRoom/RongChatRoom.h>
#import "RCVoiceSeatInfo.h"
#import "RCVoiceRoomInfo.h"
#import <YYModel/YYModel.h>
#import "RCInviteMessage.h"
#import "RCVoiceRoomRefreshMessage.h"

#ifdef __has_include
#if __has_include(<RongIMKit/RongIMKit.h>)
#import <RongIMKit/RongIMKit.h>
#define CMPTIMKit YES
#endif
#endif

#ifdef CMPTIMKit
#define RCIMReceiveMessageDelegate RCIMReceiveMessageDelegate
#else
#define RCIMReceiveMessageDelegate RCIMClientReceiveMessageDelegate
#endif

static NSString * const RCMicSeatInfoPrefixKey = @"RCMicSeatInfoPrefixKey";
static NSString * const RCRequestSeatPrefixKey = @"RCRequestSeatPrefixKey";
static NSString * const RCRequestSeatContentRequest = @"RCRequestSeatContentRequest";
static NSString * const RCRequestSeatContentAccept = @"RCRequestSeatContentAccept";
static NSString * const RCRequestSeatContentCancelled = @"RCRequestSeatContentCancelled";
static NSString * const RCRequestSeatContentDeny = @"RCRequestSeatContentDeny";
static NSString * const RCKickUserOutRoomContent = @"RCKickUserOutRoomContent";
static NSString * const RCRoomInfoKey = @"RCRoomInfoKey";
static NSString * const RCPickerUserSeatContent = @"RCPickerUserSeatContent";
static NSString * const RCAudienceJoinRoom = @"RCAudienceJoinRoom";
static NSString * const RCAudienceLeaveRoom = @"RCAudienceLeaveRoom";
static NSString * const RCUserOnSeatSpeakingKey = @"RCUserOnSeatSpeakingKey";

@interface RCVoiceRoomEngine()<RCRTCRoomEventDelegate, RCChatRoomKVStatusChangeDelegate, RCRTCStatusReportDelegate, RCIMReceiveMessageDelegate>

@property (nonatomic, weak, nullable) id<RCVoiceRoomDelegate> delegate;
@property (nonatomic, strong) NSHashTable* messageDelegateList;
@property (nonatomic, strong) RCRTCRoom *rtcRoom;
@property (nonatomic, assign) RCRTCLiveRoleType currentRole;
@property (nonatomic, copy) NSString *roomId;
@property (nonatomic, strong) RCVoiceRoomInfo *roomInfo;
@property (nonatomic, copy) NSString *currentUserId;
@property (nonatomic, strong) NSArray <RCVoiceSeatInfo *> *seatInfoList;
@end

@implementation RCVoiceRoomEngine

+ (RCVoiceRoomEngine *)sharedInstance {
    static dispatch_once_t onceToken;
    static RCVoiceRoomEngine *engine;
    dispatch_once(&onceToken, ^{
        engine = [[RCVoiceRoomEngine alloc] init];
    });
    return engine;
}

- (instancetype)init {
    if (self = [super init]) {
        [self addNotification];
    }
    return self;
}

#pragma mark - Public Method

- (void)initWithAppkey:(NSString *)appKey {
#warning should clear server info
    [[RCCoreClient sharedCoreClient] setServerInfo:@"http://navqa.cn.ronghub.com" fileServer:@"upload.qiniup.com"];
#ifdef CMPTIMKit
    [[RCIM sharedRCIM] initWithAppKey:appKey];
    [[RCIM sharedRCIM] setReceiveMessageDelegate:self];
    [[RCIM sharedRCIM] registerMessageType:[RCInviteMessage class]];
    [[RCIM sharedRCIM] registerMessageType:[RCVoiceRoomRefreshMessage class]];
#else
    [[RCCoreClient sharedCoreClient] initWithAppKey:appKey];
    [[RCCoreClient sharedCoreClient] setReceiveMessageDelegate:self object:nil];
    [[RCCoreClient sharedCoreClient] registerMessageType:[RCInviteMessage class]];
    [[RCCoreClient sharedCoreClient] registerMessageType:[RCVoiceRoomRefreshMessage class]];
#endif
   // [[RCCoreClient sharedCoreClient] setLogLevel: RC_Log_Level_Verbose];
    [[RCChatRoomClient sharedChatRoomClient] setRCChatRoomKVStatusChangeDelegate:self];
    [RCRTCEngine sharedInstance].statusReportDelegate = self;
}

- (void)connectWithToken:(NSString *)appToken
                 success:(RCVoiceRoomSuccessBlock)successBlock
                   error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    [[RCCoreClient sharedCoreClient] connectWithToken:appToken dbOpened:^(RCDBErrorCode code) {
        
    } success:^(NSString *userId) {
        weakSelf.currentUserId = userId;
        successBlock();
    } error:^(RCConnectErrorCode errorCode) {
        errorBlock(errorCode, @"Init token failed");
    }];
}

- (void)setDelegate:(id<RCVoiceRoomDelegate>)delegate {
    _delegate = delegate;
}

- (void)addMessageReceiveDelegate:(id<RCIMClientReceiveMessageDelegate>)delegate {
    [self.messageDelegateList addObject:delegate];
}

- (void)removeMessageReceiveDelegate:(id<RCIMClientReceiveMessageDelegate>)delegate {
    [self.messageDelegateList removeObject:delegate];
}

- (void)joinRoom:(NSString *)roomId
         success:(RCVoiceRoomSuccessBlock)successBlock
           error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    self.currentRole = RCRTCLiveRoleTypeAudience;
    self.roomId = roomId;
    [[RCChatRoomClient sharedChatRoomClient] joinChatRoom:roomId messageCount: -1 success:^{
        [weakSelf notifyVoiceRoom:RCAudienceJoinRoom content:self.currentUserId];
        [weakSelf joinRTCRoom:roomId role:weakSelf.currentRole success:^{
            [weakSelf changeUserRoleIfNeeded];
            successBlock();
        } error:errorBlock];
    } error:^(RCErrorCode status) {
        errorBlock(status, @"Join ChatRoom Failed");
    }];
}

- (void)leaveRoom:(RCVoiceRoomSuccessBlock)successBlock
                   error:(RCVoiceRoomErrorBlock)errorBlock {
    dispatch_group_t group = dispatch_group_create();
    __weak typeof(self) weakSelf = self;
    NSInteger userOnSeatIndex = [self seatIndexWhichUserSit:self.currentUserId];
    dispatch_group_enter(group);
    if (userOnSeatIndex >= 0) {
        [self leaveSeat:userOnSeatIndex success:^{
            dispatch_group_leave(group);
        } error:^(NSInteger code, NSString * _Nonnull msg) {
            dispatch_group_leave(group);
        }];
    } else {
        dispatch_group_leave(group);
    }
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        [self notifyVoiceRoom:RCAudienceLeaveRoom content:self.currentUserId];
        [[RCChatRoomClient sharedChatRoomClient] quitChatRoom:self.roomId success:^{
            NSLog(@"leave chat room success");
        } error:^(RCErrorCode status) {
            errorBlock(status, @"leave chat room failed");
            NSLog(@"leave chat room failed");
        }];
        [[RCRTCEngine sharedInstance] leaveRoom:^(BOOL isSuccess, RCRTCCode code) {
            if (isSuccess) {
                [weakSelf clearAll];
                successBlock();
            } else {
                errorBlock(code, @"leave rtc room failed");
            }
        }];
    });
}

- (void)enterSeat:(NSUInteger)seatIndex success:(RCVoiceRoomSuccessBlock)successBlock error:(RCVoiceRoomErrorBlock)errorBlock  {
    if (![self seatIndexInRange:seatIndex]) {
        errorBlock(-1, @"index not correct");
        return;
    }
    RCVoiceSeatInfo *seatInfo = [self.seatInfoList[seatIndex] copy];
    if ([self.currentUserId isEqualToString:seatInfo.userId] && self.currentRole == RCRTCLiveRoleTypeAudience) {
        [self switchRole:RCRTCLiveRoleTypeBroadcaster success:^{
            successBlock();
        } error:errorBlock];
        return;;
    }
    if (!(seatInfo.status == RCSeatStatusEmpty)) {
        errorBlock(-1, @"seat is locked or using");
        return;
    }
    if ([self isUserOnSeat:self.currentUserId]) {
        errorBlock(-1, @"User is on seat now");
        return;
    }
    seatInfo.userId = self.currentUserId;
    seatInfo.status = RCSeatStatusUsed;
    __weak typeof(self) weakSelf = self;
    [self updateKvSeatInfo:seatInfo seatIndex: seatIndex success:^{
        [weakSelf runMainQueue:^{
            [weakSelf replaceSeatWithIndex:seatIndex seatInfo:seatInfo];
            if ([weakSelf.delegate respondsToSelector:@selector(userDidEnterSeat:user:)]) {
                [weakSelf.delegate userDidEnterSeat:seatIndex user:weakSelf.currentUserId];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
        }];
        [weakSelf switchRole:RCRTCLiveRoleTypeBroadcaster success:successBlock error:errorBlock];
    } error: errorBlock];
}

- (void)leaveSeat:(NSUInteger)seatIndex success:(RCVoiceRoomSuccessBlock)successBlock error:(RCVoiceRoomErrorBlock)errorBlock  {
    if (![self seatIndexInRange:seatIndex]) {
        errorBlock(-1, @"index not correct");
        return;
    }
    RCVoiceSeatInfo *seatInfo = [self.seatInfoList[seatIndex] copy];
    seatInfo.userId = nil;
    seatInfo.status = RCSeatStatusEmpty;
    __weak typeof(self) weakSelf = self;
    [self updateKvSeatInfo:seatInfo seatIndex: seatIndex success:^{
        [weakSelf runMainQueue:^{
            [weakSelf replaceSeatWithIndex:seatIndex seatInfo:seatInfo];
            if ([weakSelf.delegate respondsToSelector:@selector(userDidLeaveSeat:user:)]) {
                [weakSelf.delegate userDidLeaveSeat:seatIndex user:weakSelf.currentUserId];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
        }];
        [weakSelf switchRole:RCRTCLiveRoleTypeAudience success:successBlock error:errorBlock];
    } error:errorBlock];
}

- (void)switchSeatTo:(NSUInteger)seatIndex
             success:(RCVoiceRoomSuccessBlock)successBlock
               error:(RCVoiceRoomErrorBlock)errorBlock {
    NSInteger previousIndex = [self seatIndexWhichUserSit:self.currentUserId];
    if (previousIndex < 0) {
        errorBlock(-1, @"not on seat now");
        return;
    }
    if (![self seatIndexInRange:seatIndex]) {
        errorBlock(-1, @"target index not in range");
        return;
    }
    RCVoiceSeatInfo *previousSeatInfo = self.seatInfoList[previousIndex].copy;
    RCVoiceSeatInfo *targetSeatInfo = self.seatInfoList[seatIndex].copy;
    if (!(targetSeatInfo.status == RCSeatStatusEmpty)) {
        errorBlock(-1, @"seat is locked or using");
        return;
    }
    
    previousSeatInfo.userId = nil;
    previousSeatInfo.status = RCSeatStatusEmpty;
    __weak typeof(self) weakSelf = self;
    [self updateKvSeatInfo:previousSeatInfo seatIndex: previousIndex success:^{
        [weakSelf runMainQueue:^{
            [weakSelf replaceSeatWithIndex:previousIndex seatInfo:previousSeatInfo];
            if ([weakSelf.delegate respondsToSelector:@selector(userDidLeaveSeat:user:)]) {
                [weakSelf.delegate userDidLeaveSeat:previousIndex user:weakSelf.currentUserId];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
        }];
    } error:errorBlock];
    
    targetSeatInfo.userId = self.currentUserId;
    targetSeatInfo.status = RCSeatStatusUsed;
    [self updateKvSeatInfo:targetSeatInfo seatIndex: seatIndex success:^{
        [weakSelf runMainQueue:^{
            [weakSelf replaceSeatWithIndex:seatIndex seatInfo:targetSeatInfo];
            if ([weakSelf.delegate respondsToSelector:@selector(userDidEnterSeat:user:)]) {
                [weakSelf.delegate userDidEnterSeat:seatIndex user:weakSelf.currentUserId];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
            [weakSelf muteSelfIfNeeded];
            successBlock();
        }];
    } error: errorBlock];
}

- (void)pickSeat:(NSString *)userId
                   success:(RCVoiceRoomSuccessBlock)successBlock
                     error:(RCVoiceRoomErrorBlock)errorBlock {
    if ([self isUserOnSeat:userId]) {
        errorBlock(-1, @"user alredy on seat");
        return;
    }
    if ([self.currentUserId isEqualToString:userId]) {
        errorBlock(-1, @"user can't pick self on seat");
        return;
    }
    NSString *uuid = [[NSUUID UUID] UUIDString];
    RCInviteMessage *message = [[RCInviteMessage alloc] init];
    message.sendUserId = self.currentUserId;
    message.cmd = RCInviteCmdTypeRequest;
    message.content = RCPickerUserSeatContent;
    message.invitationId = uuid;
    message.targetId = userId;
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:message pushContent:nil pushData:nil success:^(long messageId) {
        successBlock();
    } error:^(RCErrorCode nErrorCode, long messageId) {
        errorBlock(nErrorCode, @"pick user seat failed");
    }];
}

- (void)kickSeat:(NSString *)userId
                   success:(RCVoiceRoomSuccessBlock)successBlock
                     error:(RCVoiceRoomErrorBlock)errorBlock {
    NSInteger userSeatIndex = [self seatIndexWhichUserSit: userId];
    if (userSeatIndex < 0) {
        errorBlock(-1, @"user not on seat");
        return;
    }
    if ([self.currentUserId isEqualToString:userId]) {
        errorBlock(-1, @"user can't kick self");
        return;
    }
    RCVoiceSeatInfo *seatInfo = self.seatInfoList[userSeatIndex].copy;
    seatInfo.status = RCSeatStatusEmpty;
    seatInfo.userId = nil;
    __weak typeof(self) weakSelf = self;
    [self updateKvSeatInfo:seatInfo seatIndex: userSeatIndex success:^{
        [weakSelf runMainQueue:^{
            [weakSelf replaceSeatWithIndex:userSeatIndex seatInfo:seatInfo];
            if ([weakSelf.delegate respondsToSelector:@selector(userDidLeaveSeat:user:)]) {
                [weakSelf.delegate userDidLeaveSeat:userSeatIndex user:userId];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
            successBlock();
        }];
    } error:errorBlock];
}

- (void)kickOutRoom:(NSString *)userId
                      success:(RCVoiceRoomSuccessBlock)successBlock
                        error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    NSString *uuid = [[NSUUID UUID] UUIDString];
    RCInviteMessage *message = [[RCInviteMessage alloc] init];
    message.sendUserId = self.currentUserId;
    message.cmd = RCInviteCmdTypeRequest;
    message.content = RCKickUserOutRoomContent;
    message.invitationId = uuid;
    message.targetId = userId;
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:message pushContent:nil pushData:nil success:^(long messageId) {
        [weakSelf runMainQueue:^{
            if ([weakSelf.delegate respondsToSelector:@selector(userDidReceiveKickoutRoom:byUserId:)]) {
                [weakSelf.delegate userDidReceiveKickoutRoom:userId byUserId:weakSelf.currentUserId];
            }
            successBlock();
        }];
    } error:^(RCErrorCode nErrorCode, long messageId) {
        dispatch_async(dispatch_get_main_queue(), ^{
            errorBlock(nErrorCode, @"pick user seat failed");
        });
    }];
}

- (void)requestSeat:(RCVoiceRoomSuccessBlock)successBlock
                         error:(RCVoiceRoomErrorBlock)errorBlock {
    [[RCChatRoomClient sharedChatRoomClient] getAllChatRoomEntries:self.roomId success:^(NSDictionary * _Nonnull entry) {
        NSMutableArray *requestKeys = [NSMutableArray array];
        for (NSString *key in entry.allKeys) {
            if ([key containsString:self.currentUserId] && [entry[key] isEqualToString:RCRequestSeatContentRequest]) {
                errorBlock(-1, @"已经在排麦中");
                return;;
            }
            if ([key hasPrefix:RCRequestSeatPrefixKey]) {
                [requestKeys addObject:key];
            }
        }
        if (requestKeys.count > 20) {
            errorBlock(-1, @"排麦人数过多");
            return;
        }
        [self updateRequestSeatKvWithUserID:self.currentUserId content:RCRequestSeatContentRequest success:successBlock error:errorBlock];
    } error:^(RCErrorCode nErrorCode) {
        errorBlock(nErrorCode, @"get entries failed");
    }];
}

- (void)cancelRequestSeat:(RCVoiceRoomSuccessBlock)successBlock
                               error:(RCVoiceRoomErrorBlock)errorBlock {
    [RCChatRoomClient.sharedChatRoomClient removeChatRoomEntry:self.roomId key:[self RequestSeatKvKey:self.currentUserId] sendNotification:NO notificationExtra:@"" success:successBlock error:^(RCErrorCode nErrorCode) {
        errorBlock(nErrorCode, @"取消排麦请求成功");
    }];
}

- (void)acceptRequestSeat:(NSString *)userId
                            success:(RCVoiceRoomSuccessBlock)successBlock
                              error:(RCVoiceRoomErrorBlock)errorBlock {
    [self updateRequestSeatKvWithUserID:userId content:RCRequestSeatContentAccept success:successBlock error:errorBlock];
}

- (void)getRequestSeatUserIds:(void (^)(NSArray<NSString *>*))successBlock
                                       error:(RCVoiceRoomErrorBlock)errorBlock {
    [[RCChatRoomClient sharedChatRoomClient] getAllChatRoomEntries:self.roomId success:^(NSDictionary * _Nonnull entry) {
        NSMutableArray *userlist = [NSMutableArray array];
        for (NSString *key in entry.allKeys) {
            if ([key hasPrefix:RCRequestSeatPrefixKey]) {
                NSArray *list = [key componentsSeparatedByString:@"_"];
                if (list.count == 2 && [entry[key] isEqualToString:RCRequestSeatContentRequest]) {
                    [userlist addObject:list[1]];
                }
            }
        }
        successBlock(userlist);
    } error:^(RCErrorCode nErrorCode) {
        errorBlock(nErrorCode, @"get entries failed");
    }];
}

- (void)lockSeat:(NSUInteger)seatIndex
            lock:(BOOL)isLocked
         success:(RCVoiceRoomSuccessBlock)successBlock
           error:(RCVoiceRoomErrorBlock)errorBlock {
    if (![self seatIndexInRange:seatIndex]) {
        errorBlock(-1, @"index not correct");
        return;
    }
    RCVoiceSeatInfo *seatInfo = [self.seatInfoList[seatIndex] copy];
    if (seatInfo.status == RCSeatStatusUsed || seatInfo.userId != nil) {
        errorBlock(-1, @"Seat is not empty");
        return;
    }
    if (isLocked) {
        seatInfo.status = RCSeatStatusLock;
    } else {
        seatInfo.status = RCSeatStatusEmpty;
    }
    __weak typeof(self) weakSelf = self;
    [self updateKvSeatInfo:seatInfo seatIndex: seatIndex success:^{
        [weakSelf replaceSeatWithIndex:seatIndex seatInfo:seatInfo];
        [weakSelf runMainQueue:^{
            if ([weakSelf.delegate respondsToSelector:@selector(seatDidLock:isLock:)]) {
                [weakSelf.delegate seatDidLock:seatIndex isLock:isLocked];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
            successBlock();
        }];
    } error: errorBlock];
    
}

- (void)muteSeat:(NSUInteger)seatIndex
            mute:(BOOL)isMute
         success:(RCVoiceRoomSuccessBlock)successBlock
           error:(RCVoiceRoomErrorBlock)errorBlock {
    if (![self seatIndexInRange:seatIndex]) {
        errorBlock(-1, @"index not correct");
        return;
    }
    RCVoiceSeatInfo *seatInfo = [self.seatInfoList[seatIndex] copy];
    seatInfo.mute = isMute;
    __weak typeof(self) weakSelf = self;
    [self updateKvSeatInfo:seatInfo seatIndex: seatIndex success:^{
        [weakSelf replaceSeatWithIndex:seatIndex seatInfo:seatInfo];
        [weakSelf runMainQueue:^{
            [weakSelf muteSelfIfNeeded];
            if ([weakSelf.delegate respondsToSelector:@selector(seatDidMute:isMute:)]) {
                [weakSelf.delegate seatDidMute:seatIndex isMute:isMute];
            }
            if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
                [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
            }
        }];
        successBlock();
    } error: errorBlock];
}

- (void)muteOtherSeats:(BOOL)isMute {
    dispatch_group_t group = dispatch_group_create();
    for (int i = 0; i < self.seatInfoList.count; i++) {
        RCVoiceSeatInfo *seatInfo = [self.seatInfoList[i] copy];
        if (![self seatIndexInRange:i]) {
            continue;
        }
        if([self.currentUserId isEqualToString:seatInfo.userId]) {
            continue;
        }
        seatInfo.mute = isMute;
        __weak typeof(self) weakSelf = self;
        dispatch_group_enter(group);
        [self updateKvSeatInfo:seatInfo seatIndex: i success:^{
            [weakSelf replaceSeatWithIndex:i seatInfo:seatInfo];
            [weakSelf runMainQueue:^{
                [weakSelf muteSelfIfNeeded];
            }];
            dispatch_group_leave(group);
        } error:^(NSInteger code, NSString *msg) {
            dispatch_group_leave(group);
        }];
    }
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        if ([self.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
            [self.delegate seatInfoDidChanged:self.seatInfoList];
        }
    });
}

- (void)muteAllRemoteStreams:(BOOL)isMute {
    [self.rtcRoom muteAllRemoteAudio:isMute];
}

- (void)lockOtherSeats:(BOOL)isLock {
    dispatch_group_t group = dispatch_group_create();
    for (int i = 0; i < self.seatInfoList.count; i++) {
        if (![self seatIndexInRange:i]) {
            continue;
        }
        RCVoiceSeatInfo *seatInfo = [self.seatInfoList[i] copy];
        if (seatInfo.status == RCSeatStatusUsed || seatInfo.userId != nil) {
            continue;;
        }
        if (isLock) {
            seatInfo.status = RCSeatStatusLock;
        } else {
            seatInfo.status = RCSeatStatusEmpty;
        }
        dispatch_group_enter(group);
        __weak typeof(self) weakSelf = self;
        [self updateKvSeatInfo:seatInfo seatIndex: i success:^{
            [weakSelf replaceSeatWithIndex:i seatInfo:seatInfo];
            dispatch_group_leave(group);
        } error:^(NSInteger code, NSString * _Nonnull msg) {
            dispatch_group_leave(group);
        }];
    }
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        if ([self.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
            [self.delegate seatInfoDidChanged:self.seatInfoList];
        }
    });
}

- (void)sendMessage:(RCMessageContent *)message
            success:(RCVoiceRoomSuccessBlock)successBlock
              error:(RCVoiceRoomErrorBlock)errorBlock {
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:message pushContent:nil pushData:nil success:^(long messageId) {
        successBlock();
    } error:^(RCErrorCode nErrorCode, long messageId) {
        errorBlock(nErrorCode, @"send message failed");
    }];
}

- (void)notifyVoiceRoom:(NSString *)name content:(NSString *)content {
    RCVoiceRoomRefreshMessage *refreshMessage = [[RCVoiceRoomRefreshMessage alloc] init];
    refreshMessage.name = name;
    refreshMessage.content = content;
    [self sendMessage:refreshMessage success:^{
        
    } error:^(NSInteger code, NSString * _Nonnull msg) {
        
    }];
}

- (void)setRoomInfo:(RCVoiceRoomInfo *)roomInfo
            success:(RCVoiceRoomSuccessBlock)successBlock
              error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    self.roomInfo = roomInfo;
    [self updateKvRoomInfo:self.roomInfo success:^{
        if ([weakSelf.delegate respondsToSelector:@selector(roomInfoDidChanged:)]) {
            [weakSelf.delegate roomInfoDidChanged:weakSelf.roomInfo.copy];
            successBlock();
        }
    } error:errorBlock];
}

- (void)disableAudioRecording:(BOOL)isDisable {
    [[RCRTCEngine sharedInstance].defaultAudioStream setMicrophoneDisable:isDisable];
}

- (void)enableSpeaker:(BOOL)isEnable {
    [[RCRTCEngine sharedInstance] enableSpeaker:isEnable];
}

- (void)setAuidoQuality:(RCRTCAudioQuality)quality scenario:(RCRTCAudioScenario)scenario {
    [[[RCRTCEngine sharedInstance] defaultAudioStream] setAudioQuality:quality Scenario:scenario];
}

- (void)sendInvitation:(NSString *)content
                          success:(void (^)(NSString *))successBlock
                            error:(RCVoiceRoomErrorBlock)errorBlock {
    RCInviteMessage *inviteMessage = [[RCInviteMessage alloc] init];
    NSString *uuid = [[NSUUID UUID] UUIDString];
    inviteMessage.invitationId = uuid;
    inviteMessage.sendUserId = self.currentUserId;
    inviteMessage.cmd = RCInviteCmdTypeRequest;
    inviteMessage.content = content;
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:inviteMessage pushContent:nil pushData:nil success:^(long messageId) {
        successBlock(uuid);
    } error:^(RCErrorCode nErrorCode, long messageId) {
        errorBlock(nErrorCode, @"send invitation failed");
    }];
}

- (void)rejectInvitation:(NSString *)invitationId
                 success:(RCVoiceRoomSuccessBlock)successBlock
                   error:(RCVoiceRoomErrorBlock)errorBlock {
    RCInviteMessage *inviteMessage = [[RCInviteMessage alloc] init];
    inviteMessage.invitationId = invitationId;
    inviteMessage.sendUserId = self.currentUserId;
    inviteMessage.cmd = RCInviteCmdTypeReject;
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:inviteMessage pushContent:nil pushData:nil success:^(long messageId) {
        successBlock();
    } error:^(RCErrorCode nErrorCode, long messageId) {
        errorBlock(nErrorCode, @"reject invitation failed");
    }];
}
- (void)acceptInvitation:(NSString *)invitationId
                 success:(RCVoiceRoomSuccessBlock)successBlock
                   error:(RCVoiceRoomErrorBlock)errorBlock {
    RCInviteMessage *inviteMessage = [[RCInviteMessage alloc] init];
    inviteMessage.invitationId = invitationId;
    inviteMessage.sendUserId = self.currentUserId;
    inviteMessage.cmd = RCInviteCmdTypeAccept;
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:inviteMessage pushContent:nil pushData:nil success:^(long messageId) {
        successBlock();
    } error:^(RCErrorCode nErrorCode, long messageId) {
        errorBlock(nErrorCode, @"accept invitation failed");
    }];
}
- (void)cancelInvitation:(NSString *)invitationId
                 success:(RCVoiceRoomSuccessBlock)successBlock
                   error:(RCVoiceRoomErrorBlock)errorBlock {
    RCInviteMessage *inviteMessage = [[RCInviteMessage alloc] init];
    inviteMessage.invitationId = invitationId;
    inviteMessage.sendUserId = self.currentUserId;
    inviteMessage.cmd = RCInviteCmdTypeCancel;
    [[RCCoreClient sharedCoreClient] sendMessage:ConversationType_CHATROOM targetId:self.roomId content:inviteMessage pushContent:nil pushData:nil success:^(long messageId) {
        successBlock();
    } error:^(RCErrorCode nErrorCode, long messageId) {
        errorBlock(nErrorCode, @"cancel invitation failed");
    }];
}

#pragma mark - RCRTCStatusReportDelegate

- (void)didReportStatusForm:(RCRTCStatusForm *)form {
    NSInteger userSeatIndex = [self seatIndexWhichUserSit:self.currentUserId];
    if (userSeatIndex >= 0) {
        for (RCRTCStreamStat *status in form.sendStats) {
            if ([status.mediaType isEqualToString:RongRTCMediaTypeAudio]) {
                NSString *speaking = @"0";
                if (status.audioLevel > 0) {
                    speaking = @"1";
                } else {
                    speaking = @"0";
                }
                [self notifyVoiceRoom:[self speakingKey:userSeatIndex] content:speaking];
                __weak typeof(self) weakSelf = self;
                [self runMainQueue:^{
                    if ([weakSelf.delegate respondsToSelector:@selector(speakingStateDidChanged:speakingState:)]) {
                        [weakSelf.delegate speakingStateDidChanged:userSeatIndex speakingState:[speaking isEqualToString:@"1"]];
                    }
                }];
                break;
            }
        }
    }
}

#pragma mark - RCRTCRoomEventDelegate

- (void)didPublishStreams:(NSArray<RCRTCInputStream *> *)streams {
    if (self.rtcRoom != nil && self.currentRole == RCRTCLiveRoleTypeBroadcaster) {
        [self.rtcRoom.localUser subscribeStream:streams tinyStreams:@[] completion:^(BOOL isSuccess, RCRTCCode code) {

        }];
    }
}

- (void)didPublishLiveStreams:(NSArray<RCRTCInputStream *> *)streams {
    if (self.rtcRoom != nil && self.currentRole == RCRTCLiveRoleTypeAudience) {
        [self.rtcRoom.localUser subscribeStream:streams tinyStreams:@[] completion:^(BOOL isSuccess, RCRTCCode code) {

        }];
    }
}

#ifdef CMPTIMKit
#pragma mark - RCIMReceiveMessageDelegate
- (void)onRCIMReceiveMessage:(RCMessage *)message left:(int)left {
    //  请勿在此次coding，该方法只用于兼容IMKit，delegates回调在RCIMClientReceiveMessageDelegate中处理
    [self onReceived:message left:left object:nil];
}

- (BOOL)onRCIMCustomAlertSound:(RCMessage *)message {
    return true;
}
#endif

#pragma mark - RCIMClientReceiveMessageDelegate
- (void)onReceived:(RCMessage *)message left:(int)nLeft object:(id)object {
    for (id<RCIMClientReceiveMessageDelegate> delegate in self.messageDelegateList) {
        if ([delegate respondsToSelector:@selector(onReceived:left:object:)]) {
            [delegate onReceived:message left:nLeft object:object];
        }
    }
    if ([self.delegate respondsToSelector:@selector(messageDidReceived:)]) {
        [self.delegate messageDidReceived:message];
    }
    __weak typeof(self) weakSelf = self;
    [self runMainQueue:^{
        [weakSelf handleInvitationMessage:message];
        [weakSelf handleRefreshMessage:message];
    }];
}

#pragma mark - RCChatRoomKVStatusChangeDelegate

- (void)chatRoomKVDidSync:(NSString *)roomId {
    NSLog(@"kv sync");

}

- (void)chatRoomKVDidUpdate:(NSString *)roomId entry:(NSDictionary<NSString *,NSString *> *)entry {
    NSLog(@"kv updated");
    __weak typeof(self) weakSelf = self;
    [self runMainQueue:^{
        [weakSelf updateRoomInfoFromEntry:entry];
        [weakSelf resetSeatInfoWithCount:weakSelf.roomInfo.seatCount];
        [weakSelf updateSeatInfoFromEntry:entry];
        [weakSelf handleRequestSeatKvUpdated:entry];
    }];
}

- (void)chatRoomKVDidRemove:(NSString *)roomId entry:(NSDictionary<NSString *,NSString *> *)entry {
    [self handleRequestSeatCancelled:entry];
}

#pragma mark - Getter & Setter
- (NSHashTable *)messageDelegateList {
    if (!_messageDelegateList) {
        _messageDelegateList = [NSHashTable weakObjectsHashTable];
    }
    return _messageDelegateList;
}

#pragma mark - Private Method

- (void)handleInvitationMessage:(RCMessage *)message {
    if ([message.content isKindOfClass:[RCInviteMessage class]]) {
        if (message.conversationType == ConversationType_CHATROOM && [message.targetId isEqualToString:self.roomId]) {
            RCInviteMessage *inviteMessage = (RCInviteMessage *)message.content;
            switch (inviteMessage.cmd) {
                case RCInviteCmdTypeRequest:
                    if ([inviteMessage.content isEqualToString:RCPickerUserSeatContent] && [inviteMessage.targetId isEqualToString:self.currentUserId]) {
                        if ([self.delegate respondsToSelector:@selector(pickSeatDidReceivedFrom:)]) {
                            [self.delegate pickSeatDidReceivedFrom:inviteMessage.sendUserId];
                        }
                        break;
                    }
                    if ([inviteMessage.content isEqualToString:RCKickUserOutRoomContent]) {
                        if ([self.delegate respondsToSelector:@selector(userDidReceiveKickoutRoom:byUserId:)]) {
                            [self.delegate userDidReceiveKickoutRoom:inviteMessage.targetId byUserId:inviteMessage.sendUserId];
                        }
                        break;
                    }
                    if ([self.delegate respondsToSelector:@selector(invitationDidReceived:from:content:)]) {
                        [self.delegate invitationDidReceived:inviteMessage.invitationId from:inviteMessage.sendUserId content:inviteMessage.content];
                        break;
                    }
                    break;
                case RCInviteCmdTypeAccept:
                    if ([self.delegate respondsToSelector:@selector(invitationDidAccepted:)]) {
                        [self.delegate invitationDidAccepted:inviteMessage.invitationId];
                    }
                    break;
                case RCInviteCmdTypeReject:
                    if ([self.delegate respondsToSelector:@selector(invitationDidRejected:)]) {
                        [self.delegate invitationDidRejected:inviteMessage.invitationId];
                    }
                    break;
                case RCInviteCmdTypeCancel:
                    if ([self.delegate respondsToSelector:@selector(invitationDidCancelled:)]) {
                        [self.delegate invitationDidCancelled:inviteMessage.invitationId];
                    }
                    break;
                default:
                    break;
            }
        }
    }
}

- (void)handleRefreshMessage:(RCMessage *)message {
    if ([message.content isKindOfClass:[RCVoiceRoomRefreshMessage class]]) {
        if (message.conversationType == ConversationType_CHATROOM && [message.targetId isEqualToString:self.roomId]) {
            RCVoiceRoomRefreshMessage *refreshMessage = (RCVoiceRoomRefreshMessage *)message.content;
            if ([refreshMessage.name isEqualToString:RCAudienceJoinRoom]) {
                if ([self.delegate respondsToSelector:@selector(audienceDidEnter:)]) {
                    [self.delegate audienceDidEnter:refreshMessage.content];
                }
            } else if ([refreshMessage.name isEqualToString:RCAudienceLeaveRoom]) {
                if ([self.delegate respondsToSelector:@selector(audienceDidExit:)]) {
                    [self.delegate audienceDidExit:refreshMessage.content];
                }
            }
            if ([refreshMessage.name containsString:RCUserOnSeatSpeakingKey]) {
                NSArray *list = [refreshMessage.name componentsSeparatedByString:@"_"];
                if (list.count == 2) {
                    NSInteger seatIndex = [list[1] integerValue];
                    if ([self seatIndexInRange:seatIndex] && [self.delegate respondsToSelector:@selector(speakingStateDidChanged:speakingState:)]) {
                        [self.delegate speakingStateDidChanged:seatIndex speakingState:[refreshMessage.content isEqualToString:@"1"]];
                    }
                }
            }
            if ([self.delegate respondsToSelector:@selector(roomNotificationDidReceived:content:)]) {
                [self.delegate roomNotificationDidReceived:refreshMessage.name content:refreshMessage.content];
            }
        }
    }
}

- (NSString *)seatInfoKvKey:(NSUInteger)index {
    return [NSString stringWithFormat:@"%@_%lu", RCMicSeatInfoPrefixKey, (unsigned long)index];
}

- (NSString *)speakingKey:(NSUInteger)index {
    return [NSString stringWithFormat:@"%@_%lu", RCUserOnSeatSpeakingKey, (unsigned long)index];
}

- (NSString *)RequestSeatKvKey:(NSString *)content {
    return [NSString stringWithFormat:@"%@_%@", RCRequestSeatPrefixKey, content];
}

- (void)updateRoomInfoFromEntry:(NSDictionary<NSString *,NSString *> *)entry {
    if ([entry.allKeys containsObject:RCRoomInfoKey]) {
        NSString *infoJSONString = entry[RCRoomInfoKey];
        RCVoiceRoomInfo *info = [RCVoiceRoomInfo yy_modelWithJSON:infoJSONString];
        self.roomInfo = info;
        if ([self.delegate respondsToSelector:@selector(roomInfoDidChanged:)]) {
            [self.delegate roomInfoDidChanged:info.copy];
        }
        NSCAssert(info != nil, @"init room info errora");
    }
}

- (void)updateSeatInfoFromEntry:(NSDictionary<NSString *,NSString *> *)entry {
    NSMutableArray *oldMutableList = [self.seatInfoList mutableCopy];
    NSArray *latestInfoList = [self latestMicInfoListFromEntry:entry];
    NSInteger notlocked = 0;
    for (RCVoiceSeatInfo *info in latestInfoList) {
        if (info.status != RCSeatStatusLock) {
            
            notlocked++;
        }
    }
    NSLog(@"%@", entry);
    if ([self.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
        [self.delegate seatInfoDidChanged:latestInfoList];
    }
    for (int i = 0; i < self.roomInfo.seatCount; i++) {
        RCVoiceSeatInfo *new = latestInfoList[i];
        RCVoiceSeatInfo *old = oldMutableList[i];
        if (old.status != new.status) {
            switch (new.status) {
                case RCSeatStatusEmpty:
                    if (old.status == RCSeatStatusLock) {
                        if ([self.delegate respondsToSelector:@selector(seatDidLock:isLock:)]) {
                            [self.delegate seatDidLock:i isLock:NO];
                        }
                    } else {
                        // 如果下麦用户是自己，说明是被房主下麦的
                        if ([old.userId isEqualToString:self.currentUserId]) {
                            if ([self.delegate respondsToSelector:@selector(kickSeatDidReceived:)]) {
                                [self.delegate kickSeatDidReceived:i];
                            }
                            [self switchRole:RCRTCLiveRoleTypeAudience success:^{
                                
                            } error:^(NSInteger code, NSString * _Nonnull msg) {
                                
                            }];
                        } else {
                            if ([self.delegate respondsToSelector:@selector(userDidLeaveSeat:user:)]) {
                                [self.delegate userDidLeaveSeat:i user:old.userId];
                            }
                        }
                    }
                    break;
                case RCSeatStatusUsed:
                    if ([self.delegate respondsToSelector:@selector(userDidEnterSeat:user:)]) {
                        [self.delegate userDidEnterSeat:i user:new.userId];
                    }
                    break;
                case RCSeatStatusLock:
                    if ([self.delegate respondsToSelector:@selector(seatDidLock:isLock:)]) {
                        [self.delegate seatDidLock:i isLock:YES];
                    }
                    break;
                default:
                    break;
            }
        }
        if (old.isMuted != new.isMuted) {
            if ([self.delegate respondsToSelector:@selector(seatDidMute:isMute:)]) {
                [self.delegate seatDidMute:i isMute:new.isMuted];
            }
        }
    }
    self.seatInfoList = latestInfoList;
    [self muteSelfIfNeeded];
}

- (void)handleRequestSeatKvUpdated:(NSDictionary<NSString *,NSString *> *)entry {
    BOOL hasUserWaitingSeat = NO;
    for (NSString *key in entry.allKeys) {
        if ([key hasPrefix:RCRequestSeatPrefixKey]) {
            NSString *content = entry[key];
            if ([content isEqualToString:RCRequestSeatContentRequest]) {
                hasUserWaitingSeat = YES;
            }
            NSArray *list = [key componentsSeparatedByString:@"_"];
            if (list.count == 2) {
                NSString *userId = list[1];
                if ([userId isEqualToString:self.currentUserId]) {
                    if ([content isEqualToString:RCRequestSeatContentAccept]) {
                        if ([self.delegate respondsToSelector:@selector(requestSeatDidAccepted)]) {
                            [self.delegate requestSeatDidAccepted];
                        }
                        [self forceRemoveKV:key];
                    }
                    if ([content isEqual:RCRequestSeatContentDeny]) {
                        if ([self.delegate respondsToSelector:@selector(requestSeatDidRejected)]) {
                            [self.delegate requestSeatDidRejected];
                        }
                        [self forceRemoveKV:key];
                    }
                }
            }
        }
    }
    if (hasUserWaitingSeat) {
        if ([self.delegate respondsToSelector:@selector(requestSeatListDidChanged)]) {
            [self.delegate requestSeatListDidChanged];
        }
    }
}

- (void)handleRequestSeatCancelled:(NSDictionary<NSString *,NSString *> *)entry {
    for (NSString *key in entry.allKeys) {
        if ([key hasPrefix:RCRequestSeatPrefixKey]) {
            if ([self.delegate respondsToSelector:@selector(requestSeatListDidChanged)]) {
                [self.delegate requestSeatListDidChanged];
            }
        }
    }
}

- (void)changeUserRoleIfNeeded {
    NSInteger userSeatIndex = [self seatIndexWhichUserSit:self.currentUserId];
    if (userSeatIndex >= 0 && self.currentRole != RCRTCLiveRoleTypeBroadcaster) {
        [self switchRole:RCRTCLiveRoleTypeBroadcaster success:^{
            
        } error:^(NSInteger code, NSString * _Nonnull msg) {
            
        }];
    }
    if ([self.delegate respondsToSelector:@selector(roomKVDidReady)]) {
        [self.delegate roomKVDidReady];
    }
}

- (void)updateKvRoomInfo:(RCVoiceRoomInfo *)roomInfo
                 success:(RCVoiceRoomSuccessBlock)successBlock
                   error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    [[RCChatRoomClient sharedChatRoomClient] forceSetChatRoomEntry:self.roomId key:RCRoomInfoKey value:[roomInfo jsonString] sendNotification:NO autoDelete:NO notificationExtra:@"" success:^{
        [weakSelf runMainQueue:^{
            successBlock();
        }];
    } error:^(RCErrorCode nErrorCode) {
        [weakSelf runMainQueue:^{
            errorBlock(nErrorCode, @"setup Room Info failed");
        }];
    }];
}

- (void)updateKvSeatInfo:(RCVoiceSeatInfo *)info
               seatIndex:(NSUInteger)seatIndex
                 success:(RCVoiceRoomSuccessBlock)successBlock error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    [[RCChatRoomClient sharedChatRoomClient] forceSetChatRoomEntry:self.roomId key:[self seatInfoKvKey:seatIndex] value:[info yy_modelToJSONString] sendNotification:NO autoDelete:NO notificationExtra:@"" success:^{
        [weakSelf runMainQueue:^{
            successBlock();
        }];
    } error:^(RCErrorCode nErrorCode) {
        [weakSelf runMainQueue:^{
            errorBlock(-1, @"Update Seat Info failed");
        }];
    }];
}

- (void)updateRequestSeatKvWithUserID:(NSString *)userId
                              content: (NSString *)content
                              success:(RCVoiceRoomSuccessBlock)successBlock
                                error:(RCVoiceRoomErrorBlock)errorBlock {
    [[RCChatRoomClient sharedChatRoomClient] forceSetChatRoomEntry:self.roomId
                                                               key:[self RequestSeatKvKey:userId]
                                                             value:content
                                                  sendNotification:NO
                                                        autoDelete:YES
                                                 notificationExtra:@""
                                                           success:^{
        successBlock();
    } error:^(RCErrorCode nErrorCode) {
        errorBlock(nErrorCode, @"update waiting kv failed");
    }];
}

- (void)switchRole:(RCRTCLiveRoleType)role
           success:(RCVoiceRoomSuccessBlock)successBlock
             error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    if (self.currentRole != role) {
        self.currentRole = role;
        [[RCRTCEngine sharedInstance] leaveRoom:^(BOOL isSuccess, RCRTCCode code) {
            if (isSuccess) {
                [weakSelf joinRTCRoom:self.roomId role:role success:successBlock error:errorBlock];
            } else {
                errorBlock(-1, @"switch role failed");
            }
        }];
       
    }
}

- (void)joinRTCRoom:(NSString *)roomId
               role:(RCRTCLiveRoleType)role
            success:(RCVoiceRoomSuccessBlock)successBlock
              error:(RCVoiceRoomErrorBlock)errorBlock {
    __weak typeof(self) weakSelf = self;
    RCRTCRoomConfig *config = [[RCRTCRoomConfig alloc] init];
    config.roomType= RCRTCRoomTypeLive;
    config.liveType = RCRTCLiveTypeAudio;
    config.roleType = role;
    [[RCRTCEngine sharedInstance] joinRoom:roomId config:config completion:^(RCRTCRoom * _Nullable room, RCRTCCode code) {
        if (code == RCRTCCodeSuccess) {
            weakSelf.rtcRoom = room;
            weakSelf.rtcRoom.delegate = self;
            if (role == RCRTCLiveRoleTypeBroadcaster) {
                [weakSelf.rtcRoom.localUser publishDefaultStreams:^(BOOL isSuccess, RCRTCCode code) {
                    
                }];
                NSMutableArray *streams = [NSMutableArray array];
                for (RCRTCRemoteUser *remoteUser in room.remoteUsers) {
                    [streams addObjectsFromArray:remoteUser.remoteStreams];
                }
                if (streams.count > 0) {
                    [weakSelf.rtcRoom.localUser subscribeStream:streams tinyStreams:@[] completion:^(BOOL isSuccess, RCRTCCode code) {

                    }];
                }
                [weakSelf muteSelfIfNeeded];
            } else {
                [weakSelf.rtcRoom.localUser subscribeStream:[weakSelf.rtcRoom getLiveStreams] tinyStreams:@[] completion:^(BOOL isSuccess, RCRTCCode code) {
                    
                }];
            }
            [weakSelf enableSpeaker:YES];
            successBlock();
        } else {
            errorBlock(code, @"join RTC room failed");
        }
    }];
}

- (void)runMainQueue:(void(^)(void))action {
    dispatch_async(dispatch_get_main_queue(), ^{
        action();
    });
}

- (BOOL)isUserOnSeat:(NSString *)userId {
    for (RCVoiceSeatInfo *seatInfo in self.seatInfoList) {
        if ([userId isEqualToString: seatInfo.userId]) {
            return YES;
        }
    }
    return NO;
}

- (NSInteger)seatIndexWhichUserSit:(NSString *)userId {
    for (int i = 0; i < self.seatInfoList.count; i++) {
        RCVoiceSeatInfo *info = self.seatInfoList[i];
        if (info.userId == nil) {
            continue;;
        }
        if ([info.userId isEqualToString:userId]) {
            NSLog(@" null is equal to any string");
            return i;
        }
    }
    return -1;
}

- (BOOL)seatIndexInRange:(NSInteger)index {
    if (index >= 0 && index < self.seatInfoList.count) {
        return YES;
    }
    return NO;
}

- (void)resetSeatInfoWithCount:(NSInteger)seatCount {
    if (!self.seatInfoList || self.seatInfoList.count != seatCount) {
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 0; i < seatCount; i++) {
            RCVoiceSeatInfo *seatInfo = [[RCVoiceSeatInfo alloc] init];
            [array addObject:seatInfo];
        }
        self.seatInfoList = [array copy];
    }
}

- (NSArray *)latestMicInfoListFromEntry:(NSDictionary<NSString *,NSString *> *)entry {
    NSMutableArray *array = [NSMutableArray array];
    for (int i = 0; i < self.roomInfo.seatCount; i++) {
        NSString *seatKey = [self seatInfoKvKey:i];
        RCVoiceSeatInfo *new;
        if ([entry.allKeys containsObject:seatKey]) {
            new = [RCVoiceSeatInfo yy_modelWithJSON:entry[seatKey]];
        }
        if (!new) {
            new = self.seatInfoList[i];
        }
        [array addObject:new];
    }
    return [array copy];
}

- (NSString *)generateInvitationIdWithTargetId:(NSString *)targetId cmd:(NSUInteger)cmd senderId:(NSString *)senderId content:(NSString *)content {
    NSArray *array = @[senderId, targetId, [NSString stringWithFormat:@"%lud", (unsigned long)cmd]];
    if(content != nil && content.length > 0) {
        array = [array arrayByAddingObject:content];
    }
    return [array componentsJoinedByString:@","];
}

- (void)replaceSeatWithIndex:(NSUInteger)index seatInfo:(RCVoiceSeatInfo *)info {
    NSMutableArray *list = [self.seatInfoList mutableCopy];
    list[index] = info;
    self.seatInfoList = [list copy];
}

- (void)addNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleTerminateNotification:) name:UIApplicationWillTerminateNotification object:nil];
}

- (void)handleTerminateNotification: (NSNotification *)noification {
    [self leaveRoom:^{
        
    } error:^(NSInteger code, NSString * _Nonnull msg) {
        
    }];
}

- (void)updateSeatSpeakingState:(BOOL)isSpeaking
                      seatIndex:(NSUInteger)seatIndex {
    RCVoiceSeatInfo *seatInfo = self.seatInfoList[seatIndex];
    if (seatInfo.isSpeaking == isSpeaking) {
        return;
    }
    seatInfo.speaking = isSpeaking;
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"speaking state is %d", isSpeaking);
        if ([weakSelf.delegate respondsToSelector:@selector(speakingStateDidChanged:speakingState:)]) {
            [weakSelf.delegate speakingStateDidChanged:seatIndex speakingState:isSpeaking];
        }
        if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
            [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
        }
    });
    [self updateKvSeatInfo:seatInfo seatIndex: seatIndex success:^{
       
        
    } error:^(NSInteger code, NSString * _Nonnull msg) {
        
    }];
}

- (void)muteSelfIfNeeded {
    NSInteger userCurrentSeatIndex = [self seatIndexWhichUserSit:self.currentUserId];
    if (userCurrentSeatIndex >= 0) {
        RCVoiceSeatInfo *seatInfo = self.seatInfoList[userCurrentSeatIndex];
        [self disableAudioRecording:seatInfo.isMuted];
    }
}

- (void)resetSeatCount:(NSInteger)seatCount {
    dispatch_group_t group = dispatch_group_create();
    for (int i = 0; i < self.seatInfoList.count; i++) {
        RCVoiceSeatInfo *info = self.seatInfoList[i];
        dispatch_group_enter(group);
        if (info.status == RCSeatStatusUsed && info.userId != nil) {
            if (info.userId == self.currentUserId) {
                [self leaveSeat:i success:^{
                    dispatch_group_leave(group);
                } error:^(NSInteger code, NSString * _Nonnull msg) {
                    dispatch_group_leave(group);
                }];
            } else {
                [self kickSeat:info.userId success:^{
                    dispatch_group_leave(group);
                } error:^(NSInteger code, NSString * _Nonnull msg) {
                    dispatch_group_leave(group);
                }];
            }
        }
    }
    
    __weak typeof(self) weakSelf = self;
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        NSMutableArray *list = [NSMutableArray array];
        for (int i = 0; i< seatCount; i++) {
            RCVoiceSeatInfo *info = [[RCVoiceSeatInfo alloc] init];
            [list addObject:info];
            [[RCChatRoomClient sharedChatRoomClient] forceRemoveChatRoomEntry:weakSelf.roomId key:[weakSelf seatInfoKvKey:i] sendNotification:NO notificationExtra:@"" success:^{
                
            } error:^(RCErrorCode nErrorCode) {
                
            }];
        }
        weakSelf.seatInfoList = [list copy];
        if ([weakSelf.delegate respondsToSelector:@selector(seatInfoDidChanged:)]) {
            [weakSelf.delegate seatInfoDidChanged:weakSelf.seatInfoList];
        }
    });
}

- (void)forceRemoveKV:(NSString *)key {
    [[RCChatRoomClient sharedChatRoomClient] forceRemoveChatRoomEntry:self.roomId key:key sendNotification:NO notificationExtra:@"" success:^{
        
    } error:^(RCErrorCode nErrorCode) {
        
    }];
}

- (void)clearAll {
    self.roomId = nil;
    self.roomInfo = nil;
    self.seatInfoList = [NSArray array];
    self.rtcRoom = nil;
    self.delegate = nil;
}
@end

